﻿
using Tesseract;
using System.Drawing;
using AForge.Imaging.Filters;
using System.Text;
using System.Text.Json;
namespace ImageReader.Services
{
    public static class ImageReaderService
    {       
        public static  async Task<MedicareCardModel> ReadImage(IFormFile file)
        {
            var ocr = new TesseractEngine(@"C:\CarlyRepos\ImageReader\ImageReader\bin\Debug\net6.0\tessdata", "eng", EngineMode.Default);         
            var image =  new Bitmap(await StreamImageToBitmap(file));
            var filter = new BrightnessCorrection(100);
            filter.ApplyInPlace(image);
            var contrastFilter = new ContrastCorrection(100);
            contrastFilter.ApplyInPlace(image);
            var page = ocr.Process(image);
            var text = page.GetText();
            // Save extracted text to file
            File.WriteAllText("output.txt", text);
            // Clean up Tesseract engine and resources
            ocr.Dispose();
            image.Dispose();
            List<string> lines = new List<string>();
            var cardData = new MedicareCardModel();
            string[] allLines = File.ReadAllLines(@".\output.txt");
            foreach (string line in allLines)
            {
                if (!string.IsNullOrWhiteSpace(line))
                {
                    lines.Add(line);
                }
            }
            cardData.MedicareCardNumber = lines.FirstOrDefault();
            cardData.MedicareCardValidTo = lines.LastOrDefault();
            foreach (string line in lines.Skip(1).SkipLast(1))
            {
                cardData.cardholderNames.Add(line);
            }
           var json = JsonSerializer.Serialize(cardData);
            return cardData;
        }
        public static async Task<Bitmap> StreamImageToBitmap(IFormFile file)
        {
            using (var stream = new MemoryStream())
            {
                await file.CopyToAsync(stream);
                stream.Seek(0, SeekOrigin.Begin);
                return new Bitmap(stream);
            }
        }
    }
    public class MedicareCardModel
    {
        public MedicareCardModel()
        {
            cardholderNames = new List<string>();
        }
        public string? MedicareCardNumber { get; set; }
        public List<string>? cardholderNames { get; set; }
        public string? MedicareCardValidTo { get; set; }

    }
}
