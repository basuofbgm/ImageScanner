﻿using ImageReader.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace ImageReader.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ImageReaderController : ControllerBase
    {
        [HttpPost]
        [Route("UploadMedicareCard")]
        public  async Task<ActionResult> UploadMedicareCardFile(IFormFile file)
        {
            try
            {
                return Ok( JsonSerializer.Serialize(await ImageReaderService.ReadImage(file)));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
